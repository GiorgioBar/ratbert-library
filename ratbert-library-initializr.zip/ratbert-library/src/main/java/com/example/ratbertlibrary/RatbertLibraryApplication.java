package com.example.ratbertlibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatbertLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(RatbertLibraryApplication.class, args);
	}

}
